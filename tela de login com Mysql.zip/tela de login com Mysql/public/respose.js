// public/script.js
function acessarPagina() {
    let email_JS = document.getElementById("email").value;
    let password_JS = document.getElementById("password").value;
}
