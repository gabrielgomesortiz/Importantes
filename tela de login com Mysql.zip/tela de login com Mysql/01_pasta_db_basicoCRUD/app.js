const db = require('./db');

const readline = require('readline');

// Criando uma interface de leitura
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function pergunta(questao) {
    return new Promise((resolve) => {
        rl.question(questao, (resposta) => {
            resolve(resposta);
        });
    });
}

async function oqueOusuerQuerFazer() {
    const prompt1 = await pergunta("O que quer fazer? \n Digite 1 para inserir, digite 2 para procurar, digite 3 para procurar e 4 para deletar, se caso desejar visualizar users digite 5:");

    if (prompt1 == 1) {
        // Função para criar usuário
        async function criarUsuario() {
            const email = await pergunta("Digite por favor seu email: ");
            const senha = await pergunta("Digite por favor sua senha: ");

            const [result] = await db.execute(
                'INSERT INTO users (email, senha) VALUES (?, ?)',
                [email, senha]
            );
            if (result && result.insertId) {
                console.log('Usuário criado com ID:', result.insertId);
            } else {
                console.error('Erro ao criar usuário: Não foi possível inserir o usuário');
            }
        }
        await criarUsuario();  // Aguarda a criação do usuário
        process.exit(0); 
    }
    else if (prompt1 == 2) {
        // Função para procurar usuário
        async function procurarUser() {
            const id = await pergunta("Digite por favor seu ID: ");
            const [result] = await db.execute(
                'SELECT * FROM users WHERE id = ?',
                [id]
            );

            if (result && result.length > 0) {
                console.log('Usuário encontrado:', result[0]);
            } else {
                console.log('Usuário não encontrado');
            }
        }
        await procurarUser();  // Aguarda a busca do usuário
        process.exit(0); 
    }

    else if (prompt1 == 3) {
        async function atualizarUser() {
            const id = await pergunta("Digite por favor seu ID: ");
            const newEmail = await pergunta("Digite por favor novo EMAIL: ");
            const newSenha = await pergunta("Digite por favor nova SENHA: ");
            
            const [result] = await db.execute(
                'UPDATE `login`.`users` SET `email` = ?, `senha` = ? WHERE `id` = ?;',
                [newEmail, newSenha, id],
                'SELECT * FROM users WHERE id = ?;',
                [id]
            );
                console.log('\nUsuário encontrado e dados atualizados.');
        }
        await atualizarUser();  // Aguarda a busca do usuário
        process.exit(0); 
    }
    else if (prompt1 == 4) {
        async function deletarUser() {
            const id = await pergunta("Digite por favor o ID: ");
            
            const [result] = await db.execute(
                ' DELETE FROM `login`.`users` WHERE `id`=?;',
                [id]
            );
                console.log('\nUsuário deletado com sucesso');
        }
        await deletarUser();  // Aguarda a busca do usuário
        process.exit(0); 
    }
    else if(prompt1==5){
        async function mostrarTablea() {
            const [rows] = await db.execute('SELECT * FROM users');

            console.table(rows);
        }
        await mostrarTablea();  // Aguarda a busca do usuário
        process.exit(0);
    }
    rl.close();  // Fecha a interface de leitura
}

oqueOusuerQuerFazer();  // Chama a função