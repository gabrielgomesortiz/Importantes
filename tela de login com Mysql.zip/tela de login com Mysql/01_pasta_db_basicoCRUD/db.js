const mysql = require('mysql2');

// Configuração do banco de dados
const pool = mysql.createPool({
    host: 'localhost', // ou o IP do servidor do banco de dados
    user: 'root',      // usuário do banco
    password: 'Va@#1978', // senha do banco
    database: 'login'  // nome do banco de dados
});

// Exporta a pool de conexão
module.exports = pool.promise();
