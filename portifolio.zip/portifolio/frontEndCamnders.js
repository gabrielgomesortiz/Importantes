function abrirMenu(){
    let lupa= document.getElementById("lupa");
    if(lupa.style.display==="none"){
        lupa.style='margin-left:20px; display:inline';
    }
    else{
        lupa.style.display='none';
    }
    let menu = document.getElementById("menu");
    menu.style= '     align-items: start;background-color: rgb(22, 20, 20);height: 100vh;width: 200px;'
}