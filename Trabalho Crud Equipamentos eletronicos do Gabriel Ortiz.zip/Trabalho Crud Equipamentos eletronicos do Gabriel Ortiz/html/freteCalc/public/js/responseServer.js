function calcularDistancia() {
    const endereco1 = document.getElementById("origem").value;
    const endereco2 = document.getElementById("destino").value;
    const peso = document.getElementById("peso").value;
    const nomeProd = document.getElementById("nomeProd").value;
    const preco = parseInt(document.getElementById("preco").value);
    const taxaFixaLocal = document.getElementById("TaxaFixaLocal").value;

    if (!endereco1 || !endereco2 || !peso || !preco || !taxaFixaLocal || !nomeProd) {
        alert('Faltam informações nos campos.');
        return;
    }

    fetch('http://localhost:3000/calcular-distancia', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endereco1, endereco2, peso, preco, taxaFixaLocal })
    })
        .then(response => response.json())
        .then(data => {
            let number= parseFloat(data.frete)
            if (data.distancia && data.frete) {
                document.getElementById("resultado").value =
                    `O calculo foi aplicado como base nessas informações, ponto de partida: ${endereco1} e destino: ${endereco2}, com isso podemos concluimos que a distância entre as 2 localidaes é ${data.distancia} km.\n\n\nFrete: R$ ${data.frete}\n\nTotal à pagar: R$ ${number+preco}`;
            } else {
                document.getElementById("resultado").value = `Erro: ${data.error}`;
            }
        })
        .catch(error => {
            console.error('Erro ao calcular a distância:', error);
            document.getElementById("resultado").value = "Erro ao calcular a distância.";
        });
}