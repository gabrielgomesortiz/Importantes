
// Função para carregar o arquivo CSV
async function carregarCSV() {
    try {
        const response = await fetch('csv/produtoCategoria.csv');
        const data = await response.text();
        preencherCombobox(data);
    } catch (error) {
        console.error("Erro ao carregar o CSV:", error);
    }
}

// Função para processar e preencher o combobox
function preencherCombobox(csvData) {
    const select = document.getElementById('produto');
    const linhas = csvData.split('\n');

    // Limpar as opções anteriores, mantendo a primeira opção
    select.innerHTML = '<option value="">Escolha a categoria de seu Produto</option>';

    // Processar cada linha do CSV
    linhas.forEach(linha => {
        // Ignorar linhas em branco ou inválidas
        if (linha.trim() === '') return;

        const [id, nome] = linha.split(';').map(value => value.trim());
        if (id && nome) {  // Verifica se a linha tem ambos os valores
            const option = document.createElement('option');
            option.value = id;
            option.textContent = nome;
            select.appendChild(option);
        }
    });
}

// Chamar a função para carregar o CSV ao carregar a página
carregarCSV();
