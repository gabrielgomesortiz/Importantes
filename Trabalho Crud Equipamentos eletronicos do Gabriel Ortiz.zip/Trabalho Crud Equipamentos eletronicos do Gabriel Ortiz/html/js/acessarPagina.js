function calcularFrete(){
    window.location.href = "http://localhost:3000/";
}
function volatrParapaginaInicial(){
    window.location.href = "http://127.0.0.1:5500/html/indextelaPrincipal.html";
}

function direcionarParaCrud() {
    window.location.href = "http://127.0.0.1:5500/html/indexEqEletro.html"; // Substitua pelo caminho real
}
