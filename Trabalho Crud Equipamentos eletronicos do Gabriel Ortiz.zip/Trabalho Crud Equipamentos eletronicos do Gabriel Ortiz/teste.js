// Variáveis de entrada
const endereco = 'Paris, France';
const endereco2 = 'New York, USA';  // O endereço que você deseja buscar as coordenadas
const apiKey = 'ce529d6a7e8e4650a916d6b772f637c6';  // Sua chave da API (certifique-se de que está segura!)

// Criação da URL da API (substituindo o endereço e a chave)
const url = `https://api.opencagedata.com/geocode/v1/json?q=${encodeURIComponent(endereco)}&key=${apiKey}`;
const url2 = `https://api.opencagedata.com/geocode/v1/json?q=${encodeURIComponent(endereco2)}&key=${apiKey}`;

// Função para converter de graus para radianos
function degToRad(deg) {
    return deg * (Math.PI / 180);
}

// Função para calcular a distância entre dois pontos (lat1, lon1) e (lat2, lon2)
function calcularDistancia(lat1, lon1, lat2, lon2) {
    const R = 6371; // Raio da Terra em quilômetros

    // Converte as coordenadas de graus para radianos
    const lat1Rad = degToRad(lat1);
    const lon1Rad = degToRad(lon1);
    const lat2Rad = degToRad(lat2);
    const lon2Rad = degToRad(lon2);

    // Diferença entre as coordenadas
    const dLat = lat2Rad - lat1Rad;
    const dLon = lon2Rad - lon1Rad;

    // Fórmula de Haversine
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1Rad) * Math.cos(lat2Rad) * 
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    // Distância em quilômetros
    const distancia = R * c;
    return distancia;
}

// Função para fazer a requisição de geocodificação
function obterCoordenadas(url) {
    return fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.results.length > 0) {
                const lat = data.results[0].geometry.lat;
                const lon = data.results[0].geometry.lng;
                return { lat, lon };
            } else {
                console.log("Nenhuma coordenada encontrada.");
                return null;
            }
        })
        .catch(error => console.log("Erro na requisição", error));
}

// Obtendo as coordenadas de Paris primeiro
obterCoordenadas(url)
    .then(coordenadas1 => {
        if (!coordenadas1) return;

        // Depois, obtendo as coordenadas de Nova York
        return obterCoordenadas(url2).then(coordenadas2 => {
            if (!coordenadas2) return;

            // Calculando a distância entre as duas coordenadas
            const distancia = calcularDistancia(coordenadas1.lat, coordenadas1.lon, coordenadas2.lat, coordenadas2.lon);
            console.log(`A distância entre ${endereco} e ${endereco2} é de ${distancia.toFixed(2)} km.`);
        });
    })
    .catch(error => console.log("Erro no processo completo", error));
