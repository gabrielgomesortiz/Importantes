/*3) Organize no computador uma lista de Músicas. A lista deve conter o
nome da música, a duração, ano de lançamento e o nome de quem canta.*/

    class Musica{
        constructor(NomeMusica,duracao,anoDeLancamento,nomeCantor){
            this.NomeMusica=NomeMusica;
            this.duracao=duracao;
            this.anoDeLancamento=anoDeLancamento;
            this.nomeCantor=nomeCantor;
        }
    }