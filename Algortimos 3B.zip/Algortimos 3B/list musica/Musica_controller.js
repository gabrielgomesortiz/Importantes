listaDeMusicas=[
    new Musica('Bohemian Rhapsody', '5:55', '1975', 'Queen'),
    new Musica('Imagine', '3:03', '1971', 'John Lennon'),
    new Musica('Smells Like Teen Spirit', '5:01', '1991', 'Nirvana'),
    new Musica('Billie Jean', '4:54', '1982', 'Michael Jackson'),
    new Musica('Stairway to Heaven', '8:02', '1971', 'Led Zeppelin'),
    new Musica('Wonderwall', '4:18', '1995', 'Oasis')
]
function inserir(){
    const nomeMusica= document.getElementById('nomeMusica').value;
    const Duracao= document.getElementById('duracao').value;
    const AnoDeLancamento= document.getElementById('anoDeLancamento').value;
    const NomeCantor = document.getElementById('nomeCantor').value;
    limparCampos()
    let musica= new Musica(nomeMusica,Duracao,AnoDeLancamento,NomeCantor);
    listaDeMusicas.push(musica)
}
function limparCampos(){
    document.getElementById('nomeMusica').value = '';
    document.getElementById('duracao').value = '';
    document.getElementById('anoDeLancamento').value = '';
    document.getElementById('nomeCantor').value = '';
}
function listar(){
    let saida= document.getElementById("saida");
    saida.innerHTML= '';
    for(let i=0;i<listaDeMusicas.length;i++){
        let list=listaDeMusicas[i]
        saida.innerHTML+=list.NomeMusica+'-'+ list.duracao+'-'+ list.anoDeLancamento+'-'+ list.nomeCantor+'<br>';
    }
}
function zerarList(){
    listaDeMusicas=[]
    listar()
}
window.onload= listar;