let listaCelular = []; //conjunto de dados
let oQueEstaFazendo = ''; //variável global de controle
let celular = null; //variavel global 
bloquearAtributos(true);

window.onload=inserirDadosIniciais();

function procurePorChavePrimaria(chave) {
    for (let i = 0; i < listaCelular.length; i++) {
        const celular = listaCelular[i];
        if (celular.id == chave) {
            celular.posicaoNaLista = i;
            return listaCelular[i];
        }
    }
    return null;//não achou
}

// Função para procurar um elemento pela chave primária   -------------------------------------------------------------
function procure() {
    const id = document.getElementById("inputId").value;
    if (isNaN(id) || !Number.isInteger(Number(id))) {
        mostrarAviso("Precisa ser um número inteiro");
        document.getElementById("inputId").focus();
        return;
    }

    if (id) { // se digitou um Id
        celular = procurePorChavePrimaria(id);
        if (celular) { //achou na lista
            mostrarDadosCelular(celular);
            visibilidadeDosBotoes('inline', 'none', 'inline', 'inline', 'none'); // Habilita botões de alterar e excluir
            mostrarAviso("Achou na lista, pode alterar ou excluir");
        } else { //não achou na lista
            limparAtributos();
            visibilidadeDosBotoes('inline', 'inline', 'none', 'none', 'none');
            mostrarAviso("Não achou na lista, pode inserir");
        }
    } else {
        document.getElementById("inputId").focus();
        return;
    }
}
//backend->frontend
function inserir() {
    bloquearAtributos(false);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline'); //visibilidadeDosBotoes(procure,inserir,alterar,excluir,salvar)
    oQueEstaFazendo = 'inserindo';
    mostrarAviso("INSERINDO - Digite os atributos e clic o botão salvar");
    document.getElementById("inputId").focus();

}

// Função para alterar um elemento da lista
function alterar() {

    // Remove o readonly dos campos
    bloquearAtributos(false);

    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');

    oQueEstaFazendo = 'alterando';
    mostrarAviso("ALTERANDO - Digite os atributos e clic o botão salvar");
}

// Função para excluir um elemento da lista
function excluir() {
    bloquearAtributos(false);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline'); //visibilidadeDosBotoes(procure,inserir,alterar,excluir,salvar)

    oQueEstaFazendo = 'excluindo';
    mostrarAviso("EXCLUINDO - clic o botão salvar para confirmar a exclusão");
}

function salvar() {
    //gerencia operações inserir, alterar e excluir na lista

// obter os dados a partir do html

    let id;
    if (celular == null) {
         id = parseInt(document.getElementById("inputId").value);
    } else {
        id = celular.id;
    }

    const marca = document.getElementById("inputMarca").value;
    const modelo = document.getElementById("inputModelo").value;
    const fabricante = document.getElementById("inputFabricante").value;
    const dataLancamento = document.getElementById("inputDataLancamento").value;
    const memoriaRAM = parseInt(document.getElementById("inputMemoriaRAM").value);
    const memoriaROM = parseInt(document.getElementById("inputMemoriaROM").value);
    const preco = parseFloat(document.getElementById("inputPreco").value);
    //verificar se o que foi digitado pelo USUÁRIO está correto
if(id && marca && modelo && fabricante && dataLancamento && memoriaRAM && memoriaROM && preco ){// se tudo certo 
        switch (oQueEstaFazendo) {
            case 'inserindo':
                celular = new Celular(id,marca,modelo,fabricante,dataLancamento,memoriaRAM,memoriaROM,preco);
                listaCelular.push(celular);
                mostrarAviso("Inserido na lista");
                break;
            case 'alterando':
                celularAlterado = new Celular(id,marca,modelo,fabricante,dataLancamento,memoriaRAM,memoriaROM,preco);
                listaCelular[celular.posicaoNaLista] = celularAlterado;
                mostrarAviso("Alterado");
                break;
            case 'excluindo':
                let novaLista = [];
                for (let i = 0; i < listaCelular.length; i++) {
                    if (celular.posicaoNaLista != i) {
                        novaLista.push(listaCelular[i]);
                    }
                }
                listaCelular = novaLista;
                mostrarAviso("EXCLUIDO");
                break;
            default:
                // console.error('Ação não reconhecida: ' + oQueEstaFazendo);
                mostrarAviso("Erro aleatório");
        }
        visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');
        limparAtributos();
        listar();
        document.getElementById("inputId").focus();
    } else {
        alert("Erro nos dados digitados");
        return;
    }
}

//backend
function preparaListagem(vetor) {
    let texto = "";
    for (let i = 0; i < vetor.length; i++) {
        const linha = vetor[i];
        texto += 
            linha.id+" - " +
            linha.marca+" - " +
            linha.modelo+" - " +
            linha.fabricante+" - " +
            linha.dataLancamento+" - " +
            linha.memoriaRAM+" - " +
            linha.memoriaROM+" - " +
            linha.preco+"<br>";
    }
    return texto;
}

//backend->frontend (interage com html)
function listar() {
    document.getElementById("outputSaida").innerHTML = preparaListagem(listaCelular);
}

function cancelarOperacao() {
    limparAtributos();
    bloquearAtributos(true);
    visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');
    mostrarAviso("Cancelou a operação de edição");
}

function mostrarAviso(mensagem) {
    //printa a mensagem na divAviso
    document.getElementById("divAviso").innerHTML = mensagem;
}

// Função para mostrar os dados do Celular nos campos
function mostrarDadosCelular(celular) {
    document.getElementById("inputId").value = celular.id;
    document.getElementById("inputMarca").value = celular.marca;
    document.getElementById("inputModelo").value = celular.modelo;
    document.getElementById("inputFabricante").value = celular.fabricante;
    document.getElementById("inputDataLancamento").value = celular.dataLancamento;
    document.getElementById("inputMemoriaRAM").value = celular.memoriaRAM;
    document.getElementById("inputMemoriaROM").value = celular.memoriaROM;
    document.getElementById("inputPreco").value = celular.preco;

    // Define os campos como readonly
    bloquearAtributos(true);
}

// Função para limpar os dados dos campos
function limparAtributos() {
    document.getElementById("inputMarca").value = "";
    document.getElementById("inputModelo").value = "";
    document.getElementById("inputFabricante").value = "";
    document.getElementById("inputDataLancamento").value = "";
    document.getElementById("inputMemoriaRAM").value = "";
    document.getElementById("inputMemoriaROM").value = "";
    document.getElementById("inputPreco").value = "";

    bloquearAtributos(true);
}

function bloquearAtributos(soLeitura) {
    //quando a chave primaria possibilita edicao, tranca (readonly) os outros e vice-versa
    document.getElementById("inputId").readOnly = !soLeitura;
    document.getElementById("inputMarca").readOnly = soLeitura;
    document.getElementById("inputModelo").readOnly = soLeitura;
    document.getElementById("inputFabricante").readOnly = soLeitura;
    document.getElementById("inputDataLancamento").readOnly = soLeitura;
    document.getElementById("inputMemoriaRAM").readOnly = soLeitura;
    document.getElementById("inputMemoriaROM").readOnly = soLeitura;
    document.getElementById("inputPreco").readOnly = soLeitura;
}

// Função para deixar visível ou invisível os botões
function visibilidadeDosBotoes(btProcure, btInserir, btAlterar, btExcluir, btSalvar) {
    //  visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline'); 
    //none significa que o botão ficará invisível (visibilidade == none)
    //inline significa que o botão ficará visível 

    document.getElementById("btProcure").style.display = btProcure;
    document.getElementById("btInserir").style.display = btInserir;
    document.getElementById("btAlterar").style.display = btAlterar;
    document.getElementById("btExcluir").style.display = btExcluir;
    document.getElementById("btSalvar").style.display = btSalvar;
    document.getElementById("btCancelar").style.display = btSalvar; // o cancelar sempre aparece junto com o salvar
    document.getElementById("inputId").focus();
}


function inserirDadosIniciais() {
    // Lista para armazenar os celulares
    listaCelular = [];
    
    // Inicializando a lista com celulares
    let celular = new Celular(1, "Samsung", "Galaxy S22", "Samsung", "2023-01-15", 8, 128, 2999.99);
    listaCelular.push(celular);
    
    celular = new Celular(2, "Apple", "iPhone 14", "Apple", "2023-09-10", 6, 256, 7999.99);
    listaCelular.push(celular);
    
    celular = new Celular(3, "Motorola", "Moto G Power", "Motorola", "2023-05-10", 4, 64, 1899.99);
    listaCelular.push(celular);
    
    celular = new Celular(4, "Sony", "Xperia 5", "Sony", "2022-08-25", 6, 128, 2999.99);
    listaCelular.push(celular);
    
    celular = new Celular(5, "Xiaomi", "Redmi Note 11", "Xiaomi", "2022-05-30", 8, 256, 3499.99);
    listaCelular.push(celular);

    celular = new Celular(6, "LG", "Wing 5G", "LG", "2023-01-20", 8, 128, 3299.99);
    listaCelular.push(celular);

    celular = new Celular(7, "Huawei", "P50 Pro", "Huawei", "2023-03-15", 8, 512, 4999.99);
    listaCelular.push(celular);

    celular = new Celular(8, "Asus", "ROG Phone 6", "Asus", "2022-11-12", 12, 512, 6999.99);
    listaCelular.push(celular);

    celular = new Celular(9, "Nokia", "G50", "Nokia", "2022-12-01", 4, 64, 1499.99);
    listaCelular.push(celular);

    celular = new Celular(10, "OnePlus", "Nord 2", "OnePlus", "2023-06-10", 8, 256, 2999.99);
    listaCelular.push(celular);

    celular = new Celular(11, "Google", "Pixel 7", "Google", "2023-07-15", 8, 128, 3999.99);
    listaCelular.push(celular);

    celular = new Celular(12, "Oppo", "Find X5", "Oppo", "2022-09-18", 12, 256, 4199.99);
    listaCelular.push(celular);

    celular = new Celular(13, "Realme", "GT 2 Pro", "Realme", "2023-02-11", 12, 512, 4799.99);
    listaCelular.push(celular);

    listar();
    visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');
    bloquearAtributos(true);
}
function LancadoMaisTempo(){
    let comparar=0;
    let dateAtual= new Date();
    for(let i=0;i<listaCelular.length;i++){
        let data=new Date(listaCelular[i].dataLancamento)
        const  calcData= Math.ceil((dateAtual-data) / (1000 * 60 * 60 * 24));
        if(calcData>=comparar){
            comparar= calcData;
        }
    }
    let functionVerificareDepoisListar= VEDL(comparar,dateAtual);
    document.getElementById("outputSaida").innerHTML+="<br>"+preparaListagem(functionVerificareDepoisListar);

}
function VEDL(comparar,dateAtual){
    let newLista=[]
    for(let i=0;i<listaCelular.length;i++){
        let data=new Date(listaCelular[i].dataLancamento)
        const  calcData= Math.ceil((dateAtual-data) / (1000 * 60 * 60 * 24));
        if(calcData==comparar){
            newLista.push(listaCelular[i]);
        }
    }
    return newLista
}
function maisBarrato(){
    let comparar=listaCelular[0].preco

    for(let i=0;i<listaCelular.length;i++){
        let precoProd=listaCelular[i].preco;
        if(precoProd<=comparar){
            comparar= precoProd;
        }
    }
    let verificarPresso= verificar(comparar);
    document.getElementById("outputSaida").innerHTML+="<br>"+preparaListagem(verificarPresso);
}
function verificar(comparar){
    let newList=[]
    for(let i=0;i<listaCelular.length;i++){
        let precoProd=listaCelular[i].preco;
        if(precoProd===comparar){
            newList.push(listaCelular[i]);
        }
    }
    return newList;
}
function maisMemoriaRam(){

    let comparar=0;

    for(let i=0;i<listaCelular.length;i++){
        let RamProd=listaCelular[i].memoriaRAM;
        if(RamProd>=comparar){
            comparar= RamProd;
        }
    }
    let maisMemoriaRamProd= verificarRam(comparar);
    document.getElementById("outputSaida").innerHTML+="<br>"+preparaListagem(maisMemoriaRamProd);
}
function verificarRam(comparar){
    let newList=[]
    for(let i=0;i<listaCelular.length;i++){
        let precoProd=listaCelular[i].memoriaRAM;
        if(precoProd===comparar){
            newList.push(listaCelular[i]);
        }
    }
    return newList;
}