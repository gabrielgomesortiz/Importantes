let listaFrutas = []
function botaoInserir() {
    const idFruta = document.getElementById("identificador").value;
    const nomeFruta = document.getElementById("nome").value;
    const corFruta = document.getElementById("cor").value;
    const pesoFruta = document.getElementById("peso").value;

    let fruta = new Fruta(idFruta, nomeFruta, corFruta, pesoFruta)

    listaFrutas.push(fruta)
    console.log(listaFrutas)
}
function listar() {
    let saida = document.getElementById("saida");
    saida.innerHTML=''
    for(let i=0;i<listaFrutas.length;i++){
        let f= listaFrutas[i];
        saida.innerHTML+= f.id+'-'+f.nome+'-'+ f.cor+'-'+ f.peso+ "<br>"; 
    }
}