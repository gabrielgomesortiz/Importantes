class Fruta{
    constructor(id,nome,cor,peso){
        this.id=id;
        this.nome=nome;
        this.cor=cor;
        this.peso= peso;
    }
}