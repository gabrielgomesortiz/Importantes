let Ordem = 3
let m = [];
for (let i = 0; i < Ordem; i++) {
    m[i] = [];
    for (let j = 0; j < Ordem; j++) {
        m[i][j] = 0;
    }
}
let i=0;
while(i<m.length){
    let j=0;
    while(j<m[i].length){
        if(j==i){
            m[i][j]=1;
        }
        j++
    }
    i++
}
console.log(m)