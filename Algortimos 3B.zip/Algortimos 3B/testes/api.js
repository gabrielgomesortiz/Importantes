function calcularFreteCorreios() {
    const cepOrigem = "01001-000"; // CEP de origem
    const cepDestino = document.getElementById("cep").value.replace("-", ""); // CEP destino
    const url = `http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx?nCdServico=40010&sCepOrigem=${cepOrigem}&sCepDestino=${cepDestino}&nVlPeso=1&nCdFormato=1&nVlComprimento=20&nVlAltura=10&nVlLargura=15&nVlDiametro=0&sCdMaoPropria=N&nVlValorDeclarado=0&sCdAvisoRecebimento=N&StrRetorno=json`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            const valorFrete = data.Servicos.cServico.Valor;
            const prazoEntrega = data.Servicos.cServico.PrazoEntrega;
            document.getElementById("resultado").innerText = `Frete: R$ ${valorFrete}, Prazo de Entrega: ${prazoEntrega} dias`;
        })
        .catch(error => console.error("Erro ao consultar os Correios: ", error));
}
