let metros = ;
let resp = '';
let i = 0;
for (let i = 1; i < 6; i++) {
    if (i == 5) {
        let faixa3 = metros - 10;
        resp += (metros - faixa3) + ',';
        metros = faixa3;
    }
    if (metros == 11) {
        let faixa2 = metros - 10;
        resp += (metros - faixa2) + ',';
        metros = faixa2;
    }
    if (metros > 5) {
        let faixa = metros - 5;
        resp += (metros - faixa) + ','; // Adiciona o valor da faixa ao resultado
        metros = faixa; // Atualiza o valor de metros
    } else {
        resp += metros; // Se metros for <= 5, adiciona metros ao resultado
        break; // Interrompe o loop
    }

}
if (metros > 0) {
    resp+=metros // Adiciona a sobra, se houver
}
console.log(resp);
