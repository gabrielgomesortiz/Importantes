function DadosHtml() {
    let Ordem = parseInt(document.getElementById("ordemMatriz").value);
    let funcaoGerarMatriz= gerarMatriz(Ordem);
    let addNum= adicionarNumeros(funcaoGerarMatriz);
    let formatarMatriz= formatarMatrizPT(addNum)
    document.getElementById("saida").innerHTML= formatarMatriz;
}
function gerarMatriz(Ordem){
    let m=[];
    for(let i=0;i<Ordem;i++){
        m[i]=[];
        for(let j=0;j<Ordem;j++){
            m[i][j]=0;
        }
    }
    return m;
}
function adicionarNumeros(m){
    let i=0;
        while(i<m.length){
            let j=0;
            while(j<m[i].length){
                if(j==i){
                    m[i][j]=1;
                }
                j++
            }
            i++
        }
        return m;
}
function formatarMatrizPT(m){
    let output='';
    for(let i=0;i<m.length;i++){
        for(let j=0;j<m[i].length;j++){
            output+=m[i][j];
            if(j<m.length){
                output+=' ';
            }
        } 
        output+="<br>";
    }
    return output;
}