function gerarMatriz(matriz) {
    let m = [];
    let i = 0;
    while (i < matriz.length) {
        let numeros = matriz[i].split(" ").map(Number);
        m.push(numeros);
        i++
    }
    return m;
}
function gerarTransposta1(m){
    let resp = [];
    for (let i = 0; i < m[0].length; i++) {
        resp[i] = [];
        for (let j = 0; j < m.length; j++) {
            resp[i][j] = m[j][i]
        }
    }
    return resp;
}
function formatarMatrizTrasposta(resp){
    let output='';
    for(let i=0;i<resp.length;i++){
        for(let j=0;j<resp[i].length;j++){
            output+= resp[i][j];
            if(j<resp.length){
                output+= " ";
            }
        }
        output+="<br>"
    }
    return output;
}