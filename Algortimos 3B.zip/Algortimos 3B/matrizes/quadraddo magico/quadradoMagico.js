let n=7
function gerarQuadradoMagico(n) {
    if (n % 2 === 0) {
        throw new Error("Este método só funciona com números ímpares.");
    }

    // Inicializa uma matriz n x n com zeros usando loops
    let quadrado = [];
    for (let i = 0; i < n; i++) {
        quadrado[i] = [];
        for (let j = 0; j < n; j++) {
            quadrado[i][j] = 0;
        }
    }

    // Posição inicial: começa no meio da primeira linha
    let i = 0;
    let j = Math.floor(n / 2);

    // Preenche a matriz com números de 1 a n*n
    for (let num = 1; num <= n * n; num++) {
        quadrado[i][j] = num;

        // Salva a posição atual para possíveis correções
        let novoI = (i - 1 + n) % n;
        let novoJ = (j + 1) % n;

        // Se a célula já está ocupada, desce uma linha
        if (quadrado[novoI][novoJ] !== 0) {
            i = (i + 1) % n;
        } else {
            i = novoI;
            j = novoJ;
        }
    }

    return quadrado;
}

// Testando com uma matriz 3x3
const quadradoMagico = gerarQuadradoMagico(3);

// Exibindo o quadrado mágico com loop 'for'
console.log("Quadrado Mágico 3x3:");
for (let i = 0; i < quadradoMagico.length; i++) {
    console.log(quadradoMagico[i]);
}
