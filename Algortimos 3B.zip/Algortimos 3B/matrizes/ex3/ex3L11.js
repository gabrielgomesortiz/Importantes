function gerarMatriz(matris_text) {
    let m = [];
    let i = 0;
    while (i < matris_text.length) {
        let numeros = matris_text[i].split(' ').map(Number);
        m.push(numeros)
        i++
    }

    return m;
}

function formatar(m) {
    let outPut = '';
    for (let i = 0; i < m.length; i++) {
        for (let j = 0; j < m[i].length; j++) {
            outPut += m[i][j];
            if (j < m[i].length) {
                outPut += ' '
            }
        }
        outPut += '\n'
    }
    return outPut.slice(0,-1)
}
function printarDiagonalPrincipal(m) {
    let diagonal='';
    let i=0;
    while(i<m.length){
        let j=0;
        while(j<m[i].length){
            if(i==j){
                diagonal+= m[i][j]+ ', '
            }
            j++
        }
        i++
    }
    return diagonal.slice(0,-2)
}
function  printarDiagonalsecundaria(m){
    let diagonalsec='';
    let i=0;
    while(i<m.length){
        let j=0;
        while(j<m[i].length){
            if(i+j==m.length-1){
                diagonalsec+= m[i][j]+ ', '
            }
            j++
        }
        i++
    }
    return diagonalsec.slice(0,-2)
}