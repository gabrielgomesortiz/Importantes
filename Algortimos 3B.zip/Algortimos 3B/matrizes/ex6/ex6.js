function DadosHtml() {
    let matrizText = document.getElementById("matriz").value;
    let ProcurarNumeroInput = parseInt(document.getElementById("ProcurarNumero").value);
    let matriz = matrizText.trim().split("\n");
    let funcaoGerarMatriz = gerarMatriz(matriz);
    let funcaoProcurarNumero = ProcurarNumero(funcaoGerarMatriz,ProcurarNumeroInput)

    document.getElementById("saida").innerHTML= funcaoProcurarNumero;
}
function gerarMatriz(matriz) {
    let m = [];
    let i = 0;
    while (i < matriz.length) {
        let numeros = matriz[i].split(" ").map(Number);
        m.push(numeros);
        i++
    }
    return m;
}
function ProcurarNumero(m,ProcurarNumeroInput) {
    let numeroAchado = '';
    for (let i = 0; i < m.length; i++) {
        for (let j = 0; j < m[i].length; j++) {
            if(m[i][j]==ProcurarNumeroInput){
                numeroAchado="Seu numero esta na coluna:"+ (j+1) +" e na linha: "+ (i+1);
            }
        }
    }
    return numeroAchado
}