        function gerarMatriz(matriz){
            let m=[];
            let i=0;
            while(i<matriz.length){
                let numeros= matriz[i].split(' ').map(Number);
                m.push(numeros)
                i++
            }
            return m;
        }
        function formatar(m){
            let output='';
            for(let i=0;i<m.length;i++){
                for(let j=0;j<m[i].length;j++){
                    output+= m[i][j];
                    if(j<m.length-1){
                        output+= ' '
                    }
                }
                output+='\n'
            }
            return output;
        }
        function mediaSec(m){
            let mediadiagonalSec=0;
            let i=0;
            while(i<m.length){
                let j=0;
                while(j<m[i].length){
                    if(j+i==m.length-1){
                        mediadiagonalSec+= m[i][j];
                    }
                    j++
                }
                i++
            }
            return mediadiagonalSec/ m.length
        }