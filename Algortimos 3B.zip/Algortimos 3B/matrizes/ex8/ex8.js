function dadosHTML() {
    let saida = document.getElementById("saida");
    let mat_text = document.getElementById("matriz").value;
    let matriz = mat_text.trim().split('\n');
    let gerarMatriz = gerar(matriz);
    let formatarMatriz = formatar(gerarMatriz);
    let encontrarMaior = maior(gerarMatriz);
    let encontrarMenor = menor(gerarMatriz);
    saida.innerText = 'Sua matriz:' + '\n' + formatarMatriz+'\n'+encontrarMaior+'\n'+encontrarMenor;

}

function gerar(matriz) {
    let m = [];
    let i = 0
    while (i < matriz.length) {
        let numero = matriz[i].split(" ").map(Number);
        m.push(numero);
        i++
    }
    return m;
}

function formatar(m) {
    let outPut = '';
    for (let i = 0; i < m.length; i++) {
        for (let j = 0; j < m[i].length; j++) {
            let trasformaValores = String(m[i][j]).padStart(5, ' ')
            outPut += trasformaValores;
        }
        outPut += '\n'
    }
    return outPut
}

function maior(m) {
    let resp = '';
    let comparar = 0;
    for (let i = 0; i < m.length; i++) {
        for (let j = 0; j < m[i].length; j++) {
            if (m[i][j] > comparar) {
                resp = "O maior número é: " + m[i][j] + " e esta localizado na coluna: " + (j + 1) + " linha: " + (i + 1)

                comparar = m[i][j]
            }
        }
    }
    return resp;
}

function menor(m,) {
    let resp = '';
    let comparar = 0;
    for (let i = 0; i < m.length; i++) {
        for (let j = 0; j < m[i].length; j++) {
            if (m[i][j] > comparar) {
                comparar = m[i][j]
            }
        }
    }

    for (let i = 0; i < m.length; i++) {
        for (let j = 0; j < m[i].length; j++) {
            if (m[i][j] < comparar) {
                resp = "O memor número é: " + m[i][j] + " e esta localizado na coluna: " + (j + 1) + " linha: " + (i + 1)
                comparar = m[i][j]
            }
        }
    }
    return resp;
}
