function gerar(matre_text) {
    let n = 0;
    let m = [];
    while (n < matre_text.length) {
        let numeros = matre_text[n].split(' ').map(Number);
        m.push(numeros);
        n++
    }
    return m;
}

function calcCols(m) {
    let somarColunas = [];
    let i = 0;
    while (i < m[0].length) {
        somarColunas[i] = 0;
        let j = 0;
        while (j < m.length) {
            somarColunas[i] += m[j][i];
            j++;
        }
        i++;
    }
    return somarColunas;
}

function somarLinhas(m){
    let somarLinha=[]
    let i=0;
    while(i<m.length){
        somarLinha[i]=0
        let j=0;
        while(j<m[0].length){
            somarLinha[i]+=m[i][j];
            j++;
        }
        i++;
    }
    return somarLinha;
}

function calcDP(m) {
    somarDiagonal = 0;
    let i = 0;
    while (i < m.length) {
        let j = 0;
        while (j < m[0].length) {
            if (j === i) {
                somarDiagonal += m[i][j];
            }
            j++
        }
        i++
    }
    return somarDiagonal;
}

function calcDsec(m) {
    somarDiagonalSec = 0;
    let i = 0;
    while (i < m.length) {
        let j = 0;
        while (j < m[0].length) {
            if (j + i === 2) {
                somarDiagonalSec += m[i][j];
            }
            j++
        }
        i++
    }
    return somarDiagonalSec;
}

function mediaCols(somarColunas, m) {
    let media = '';
    let i = 0;
    while (i < somarColunas.length) {
        media += somarColunas[i] / m.length + ',';
        i++;
    }
    return media.slice(0, -1);
}

function mediaLinha(somarLinha,m){
    let mediaLinhas='';
    let i=0;
    while(i<somarLinha.length){
        mediaLinhas+= somarLinha[i]/m.length+ ','
        i++;
    }
    return mediaLinhas.slice(0,-1);
}