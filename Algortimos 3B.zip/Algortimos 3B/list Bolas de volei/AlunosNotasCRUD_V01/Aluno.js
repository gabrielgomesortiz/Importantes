class Aluno {
    constructor(id, peso, modelo , marca, dataDeFabricacao,posicaoNaLista) {
        this.id=id;
        this.peso=peso;
        this.modelo=modelo;
        this.marca= marca;
        this.dataDeFabricacao=dataDeFabricacao;

        this.posicaoNaLista = posicaoNaLista; //atributo para facilitar a alteração e exclusão
    }
}