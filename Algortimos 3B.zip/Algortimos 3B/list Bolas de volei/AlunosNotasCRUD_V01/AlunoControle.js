    let listaDeAlunosComedia = []; //conjunto de dados
    let oQueEstaFazendo = ''; //variável global de controle
    let boola = null; //variavel global 
    bloquearAtributos(true);
    //backend (não interage com o html)
    function procurePorChavePrimaria(chave) {
        for (let i = 0; i < listaDeAlunosComedia.length; i++) {
            const boola = listaDeAlunosComedia[i];
            if (boola.id == chave) {
                boola.posicaoNaLista = i;
                return listaDeAlunosComedia[i];
            }
        }
        return null;//não achou
    }

    // Função para procurar um elemento pela chave primária   -------------------------------------------------------------
    function procure() {
        const id = parseInt(document.getElementById("id").value);
        if (id) { // se digitou um Placa
            boola = procurePorChavePrimaria(id);
            if (boola) { //achou na lista
                mostrarDadosAluno(boola);
                visibilidadeDosBotoes('inline', 'none', 'inline', 'inline', 'none'); // Habilita botões de alterar e excluir
                mostrarAviso("Achou na lista, pode alterar ou excluir");
            } else { //não achou na lista
                limparAtributos();
                visibilidadeDosBotoes('inline', 'inline', 'none', 'none', 'none');
                mostrarAviso("Não achou na lista, pode inserir");
            }
        } else {
            document.getElementById("id").focus();
            return;
        }
    }

    //backend->frontend
    function inserir() {
        bloquearAtributos(false);
        visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline'); //visibilidadeDosBotoes(procure,inserir,alterar,excluir,salvar)
        oQueEstaFazendo = 'inserindo';
        mostrarAviso("INSERINDO - Digite os atributos e clic o botão salvar");
        document.getElementById("id").focus();

    }

    // Função para alterar um elemento da lista
    function alterar() {

        // Remove o readonly dos campos
        bloquearAtributos(false);

        visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');

        oQueEstaFazendo = 'alterando';
        mostrarAviso("ALTERANDO - Digite os atributos e clic o botão salvar");
    }

    // Função para excluir um elemento da lista
    function excluir() {
        bloquearAtributos(false);
        visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline'); //visibilidadeDosBotoes(procure,inserir,alterar,excluir,salvar)

        oQueEstaFazendo = 'excluindo';
        mostrarAviso("EXCLUINDO - clic o botão salvar para confirmar a exclusão");
    }

    function salvar() {
        //gerencia operações inserir, alterar e excluir na lista

        // obter os dados a partir do html

        let id;
        if (boola == null) {
            id = document.getElementById("id").value;
        } else {
            id = boola.id;
        }

        const dataDeFabricacao = document.getElementById("dataDeFabricacao").value;
        const peso = parseInt(document.getElementById("peso").value);
        const marca = document.getElementById("marca").value;
        const modelo = document.getElementById("modelo").value;
        //verificar se o que foi digitado pelo USUÁRIO está marcareto
        if (id && dataDeFabricacao && peso && marca && modelo) {// se tudo certo 
            switch (oQueEstaFazendo) {
                case 'inserindo':
                    boola = new Aluno(id, peso, modelo , marca, dataDeFabricacao);
                    listaDeAlunosComedia.push(boola);
                    mostrarAviso("Inserido na lista");
                    break;
                case 'alterando':
                    boolaAlterado = new Aluno(id, peso, modelo , marca, dataDeFabricacao);
                    listaDeAlunosComedia[boola.posicaoNaLista] = boolaAlterado;
                    mostrarAviso("Alterado");
                    break;
                case 'excluindo':
                    let novaLista = [];
                    for (let i = 0; i < listaDeAlunosComedia.length; i++) {
                        if (boola.posicaoNaLista != i) {
                            novaLista.push(listaDeAlunosComedia[i]);
                        }
                    }
                    listaDeAlunosComedia = novaLista;
                    mostrarAviso("EXCLUIDO");
                    break;
                default:
                    // console.error('Ação não reconhecida: ' + oQueEstaFazendo);
                    mostrarAviso("Erro aleatório");
            }
            visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');
            limparAtributos();
            listar();
            document.getElementById("id").focus();
        } else {
            alert("Erro nos dados digitados");
            return;
        }
    }

    //backend
    function preparaListagem(vetor) {
        let texto = "";
        const peso = parseInt(document.getElementById("peso").value);
        if(peso>0){
        for (let i = 0; i < vetor.length; i++) {
            const linha = vetor[i];
            texto +=
                linha.id + " - " +
                linha.peso + " - " +
                linha.modelo + " - " +
                linha.marca + "-"+
                linha.dataDeFabricacao  + "<br>";
        }
        return texto;
    }
    else{
        alert("não foi possivel realizar")
    }
    }

    //backend->frontend (interage com html)
    function listar() {
        document.getElementById("outputSaida").innerHTML = preparaListagem(listaDeAlunosComedia);
    }

    function cancelarOperacao() {
        limparAtributos();
        bloquearAtributos(true);
        visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');
        mostrarAviso("Cancelou a operação de edição");
    }

    function mostrarAviso(mensagem) {
        //printa a mensagem na divAviso
        document.getElementById("divAviso").innerHTML = mensagem;
    }

    // Função para mostrar os dados do Aluno nos campos
    function mostrarDadosAluno(boola) {
        document.getElementById("id").value = boola.id;
        document.getElementById("dataDeFabricacao").value = boola.dataDeFabricacao;
        document.getElementById("peso").value = boola.peso;
        document.getElementById("marca").value = boola.marca;
        document.getElementById("modelo").value = boola.modelo;
        // Define os campos como readonly
        bloquearAtributos(true);
    }

    // Função para limpar os dados dos campos
    function limparAtributos() {
        document.getElementById("dataDeFabricacao").value=''
        document.getElementById("peso").value = "";
        document.getElementById("marca").value = "";
        document.getElementById("modelo").value = "";
        bloquearAtributos(true);
    }

    function bloquearAtributos(soLeitura) {
        //quando a chave primaria possibilita edicao, tranca (readonly) os outros e vice-versa
        document.getElementById("id").readOnly = !soLeitura;
        document.getElementById("dataDeFabricacao").readOnly = soLeitura;
        document.getElementById("peso").readOnly = soLeitura;
        document.getElementById("marca").readOnly = soLeitura;
        document.getElementById("modelo").readOnly = soLeitura;

    }

    // Função para deixar visível ou invisível os botões
    function visibilidadeDosBotoes(btProcure, btInserir, btAlterar, btExcluir, btSalvar) {
        //  visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline'); 
        //none significa que o botão ficará invisível (visibilidade == none)
        //inline significa que o botão ficará visível 

        document.getElementById("btProcure").style.display = btProcure;
        document.getElementById("btInserir").style.display = btInserir;
        document.getElementById("btAlterar").style.display = btAlterar;
        document.getElementById("btExcluir").style.display = btExcluir;
        document.getElementById("btSalvar").style.display = btSalvar;
        document.getElementById("btCancelar").style.display = btSalvar; // o cancelar sempre aparece junto com o salvar
        document.getElementById("id").focus();
    }