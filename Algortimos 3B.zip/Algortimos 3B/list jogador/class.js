class Jogador {
    constructor(id,nome,dataDenascimento,posicaoNaLista) {
        this.id = id;
        this.nome = nome;
        this.dataDenascimento=dataDenascimento


        this.posicaoNaLista = posicaoNaLista; //atributo para facilitar a alteração e exclusão 
    }
}
