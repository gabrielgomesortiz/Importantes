let listaDeBicicletas = []; //conjunto de dados
let oQueEstaFazendo = ''; //variável global de controle
let Bike = null; //variavel global 
bloquearAtributos(true);


function salvarNoComputador() {
    nomeParaSalvar = "./Musica.csv";
    let textoCSV = "";
    for (let i = 0; i < listaDeBicicletas.length; i++) {
        const linha = listaDeBicicletas[i];
        textoCSV += linha.id + ";" +
            linha.nome + ";" +
            linha.banda + ";" +
            linha.album + ";" +
            linha.lancamento + ";" +
            linha.genero + "\n";
    }


    salvarEmArquivo(nomeParaSalvar, textoCSV);
}


function salvarEmArquivo(nomeArq, conteudo) {
    // Cria um blob com o conteúdo em formato de texto
    const blob = new Blob([conteudo], { type: 'text/plain' });
    // Cria um link temporário para o download
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = nomeArq; // Nome do arquivo de download
    // Simula o clique no link para iniciar o download
    link.click();
    // Libera o objeto URL
    URL.revokeObjectURL(link.href);
}




// Função para abrir o seletor de arquivos para upload
function buscarDadosSalvosNoComputador() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv'; // Aceita apenas arquivos CSV
    input.onchange = function (event) {
        const arquivo = event.target.files[0];
        console.log(arquivo.name);
        if (arquivo) {
            processarArquivo(arquivo);
        }
    };
    input.click(); // Simula o clique para abrir o seletor de arquivos

}

// Função para processar o arquivo CSV e transferir os dados para a listaDeBicicletas
function processarArquivo(arquivo) {
    const leitor = new FileReader();
    leitor.onload = function (e) {
        const conteudo = e.target.result; // Conteúdo do arquivo CSV
        const linhas = conteudo.split('\n'); // Separa o conteúdo por linha
        listaDeBicicletas = []; // Limpa a lista atual (se necessário)
        for (let i = 0; i < linhas.length; i++) {
            const linha = linhas[i].trim();
            if (linha) {
                const dados = linha.split(';'); // Separa os dados por ';'
                if (dados.length === 6) {
                    // Adiciona os dados à listaDeBicicletas como um objeto
                    listaDeBicicletas.push({
                        id: dados[0],
                        nome: dados[1],
                        fabricante: dados[2],
                        dataLancamento: dados[3],
                        preco: dados[4],
                        peso: dados[5]
                    });
                }
            }
        }
        // console.log("Upload concluído!", listaMusica); // Exibe no console a lista atualizada
        listar();
    };
    leitor.readAsText(arquivo); // Lê o arquivo como texto
}


//backend (não interage com o html)
function procurePorChavePrimaria(chave) {
    for (let i = 0; i < listaDeBicicletas.length; i++) {
        const Bike = listaDeBicicletas[i];
        if (Bike.id == chave) {
            Bike.posicaoNaLista = i;
            return listaDeBicicletas[i];
        }
    }
    return null;//não achou
}

// Função para procurar um elemento pela chave primária   -------------------------------------------------------------
function procure() {
    const id = document.getElementById("inputId").value;
    if (isNaN(id) || !Number.isInteger(Number(id))) {
        mostrarAviso("Precisa ser um número inteiro");
        document.getElementById("inputId").focus();
        return;
    }

    if (id) { // se digitou um Id
        Bike = procurePorChavePrimaria(id);
        if (Bike) { //achou na lista
            mostrarDadosBike(Bike);
            visibilidadeDosBotoes('inline', 'none', 'inline', 'inline', 'none'); // Habilita botões de alterar e excluir
            mostrarAviso("Achou na lista, pode alterar ou excluir");
        } else { //não achou na lista
            limparAtributos();
            visibilidadeDosBotoes('inline', 'inline', 'none', 'none', 'none');
            mostrarAviso("Não achou na lista, pode inserir");
        }
    } else {
        document.getElementById("inputId").focus();
        return;
    }
}

//backend->frontend
function inserir() {
    bloquearAtributos(false);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline'); //visibilidadeDosBotoes(procure,inserir,alterar,excluir,salvar)
    oQueEstaFazendo = 'inserindo';
    mostrarAviso("INSERINDO - Digite os atributos e clic o botão salvar");
    document.getElementById("inputId").focus();

}

// Função para alterar um elemento da lista
function alterar() {

    // Remove o readonly dos campos
    bloquearAtributos(false);

    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');

    oQueEstaFazendo = 'alterando';
    mostrarAviso("ALTERANDO - Digite os atributos e clic o botão salvar");
}

// Função para excluir um elemento da lista
function excluir() {
    bloquearAtributos(false);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline'); //visibilidadeDosBotoes(procure,inserir,alterar,excluir,salvar)

    oQueEstaFazendo = 'excluindo';
    mostrarAviso("EXCLUINDO - clic o botão salvar para confirmar a exclusão");
}

function salvar() {
    //gerencia operações inserir, alterar e excluir na lista

    // obter os dados a partir do html

    let id;
    if (Bike == null) {
        id = parseInt(document.getElementById("inputId").value);
    } else {
        id = Bike.id;
    }

    const nome = document.getElementById("inputNome").value;
    const fabricante = document.getElementById("fabricante").value;
    const dataLancamento = document.getElementById("inputDataLancamento").value;
    const preco = parseInt(document.getElementById("preco").value);
    const peso = parseInt(document.getElementById("peso").value);
    //verificar se o que foi digitado pelo USUÁRIO está correto
    if (id && nome && fabricante && dataLancamento && preco>0 && peso>0) {// se tudo certo 
        switch (oQueEstaFazendo) {
            case 'inserindo':
                Bike = new Bicicleta (id, nome, fabricante, dataLancamento, preco, peso);
                listaDeBicicletas.push(Bike);
                mostrarAviso("Inserido na lista");
                break;
            case 'alterando':
                BikeAlterado = new Bicicleta(id, nome, fabricante, dataLancamento, preco, peso);
                listaDeBicicletas[Bike.posicaoNaLista] = BikeAlterado;
                mostrarAviso("Alterado");
                break;
            case 'excluindo':
                let novaLista = [];
                for (let i = 0; i < listaDeBicicletas.length; i++) {
                    if (Bike.posicaoNaLista != i) {
                        novaLista.push(listaDeBicicletas[i]);
                    }
                }
                listaDeBicicletas = novaLista;
                mostrarAviso("EXCLUIDO");
                break;
            default:
                // console.error('Ação não reconhecida: ' + oQueEstaFazendo);
                mostrarAviso("Erro aleatório");
        }
        visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');
        limparAtributos();
        listar();
        document.getElementById("inputId").focus();
    } else {
        alert("Erro nos dados digitados");
        return;
    }
}

//backend
function preparaListagem(vetor) {
    let texto = "";
    for (let i = 0; i < vetor.length; i++) {
        const linha = vetor[i];
        texto +=
            linha.id + " - " +
            linha.nome + " - " +
            linha.fabricante + " - " +
            linha.dataLancamento + " - " +
            linha.preco + " - " +
            linha.peso + "<br>";
    }
    return texto;
}

//backend->frontend (interage com html)
function listar() {
    document.getElementById("outputSaida").innerHTML = preparaListagem(listaDeBicicletas);
}

function cancelarOperacao() {
    limparAtributos();
    bloquearAtributos(true);
    visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');
    mostrarAviso("Cancelou a operação de edição");
}

function mostrarAviso(mensagem) {
    //printa a mensagem na divAviso
    document.getElementById("divAviso").innerHTML = mensagem;
}

// Função para mostrar os dados do Bike nos campos
function mostrarDadosBike(Bike) {
    document.getElementById("inputId").value = Bike.id;
    document.getElementById("inputNome").value = Bike.nome;
    document.getElementById("fabricante").value = Bike.fabricante;
    document.getElementById("inputDataLancamento").value = Bike.dataLancamento;
    document.getElementById("preco").value = Bike.preco;
    document.getElementById("peso").value = Bike.peso;

    // Define os campos como readonly
    bloquearAtributos(true);
}

// Função para limpar os dados dos campos
function limparAtributos() {
    document.getElementById("inputNome").value = "";
    document.getElementById("fabricante").value = "";
    document.getElementById("inputDataLancamento").value = "";
    document.getElementById("preco").value = "";
    document.getElementById("peso").value = "";

    bloquearAtributos(true);
}

function bloquearAtributos(soLeitura) {
    //quando a chave primaria possibilita edicao, tranca (readonly) os outros e vice-versa
    document.getElementById("inputId").readOnly = !soLeitura;
    document.getElementById("inputNome").readOnly = soLeitura;
    document.getElementById("fabricante").readOnly = soLeitura;
    document.getElementById("inputDataLancamento").readOnly = soLeitura;
    document.getElementById("preco").readOnly = soLeitura;
    document.getElementById("peso").readOnly = soLeitura;
}

// Função para deixar visível ou invisível os botões
function visibilidadeDosBotoes(btProcure, btInserir, btAlterar, btExcluir, btSalvar) {
    //  visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline'); 
    //none significa que o botão ficará invisível (visibilidade == none)
    //inline significa que o botão ficará visível 

    document.getElementById("btProcure").style.display = btProcure;
    document.getElementById("btInserir").style.display = btInserir;
    document.getElementById("btAlterar").style.display = btAlterar;
    document.getElementById("btExcluir").style.display = btExcluir;
    document.getElementById("btSalvar").style.display = btSalvar;
    document.getElementById("btCancelar").style.display = btSalvar; // o cancelar sempre aparece junto com o salvar
    document.getElementById("inputId").focus();
}

let ListarMenores=[]
function filtrarBicicletasPorPeso(){
    const Limitedepeso = parseInt(document.getElementById("Limitedepeso").value);
   for(let i=0;i<listaDeBicicletas.length;i++){
    let bicicleta = listaDeBicicletas[i];
    if(bicicleta.peso < Limitedepeso){
        ListarMenores.push(bicicleta);
    }
    document.getElementById("outputSaida").innerHTML = preparaListagem(ListarMenores);
}
}
let ListaMaisBaratos=[];
function MostrarMaisBaratos(){

let comparar= listaDeBicicletas[0].preco;

    for(let i=1;i<listaDeBicicletas.length;i++){
        let l= listaDeBicicletas[i];
        alert(i)
        if(l.preco < comparar){
            comparar=l.preco;
        }
    }
    for(let i=0;i<listaDeBicicletas.length;i++){
        let l= listaDeBicicletas[i];
        if(comparar===l.preco){
            ListaMaisBaratos.push(listaDeBicicletas[i]);
        }
    }
    document.getElementById("outputSaida").innerHTML = preparaListagem(ListaMaisBaratos);
}