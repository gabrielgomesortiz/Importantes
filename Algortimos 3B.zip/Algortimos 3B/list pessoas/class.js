class Pessoa{
    constructor(nome,altura,dataDeNascimento,cpf){
        this.nome=nome;
        this.altura=altura;
        this.dataDeNascimento=dataDeNascimento;
        this.cpf=cpf
    }
}