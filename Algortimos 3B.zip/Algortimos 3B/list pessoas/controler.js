let ListaPessoa = [
    new Pessoa('gab', 12, "22222-02-22", "120")
]

function inserir() {
    const nome = document.getElementById("nome").value;
    const altura = parseFloat(document.getElementById("altura").value);
    const dataDeNascimento = document.getElementById("dataDeNascimento").value;
    const cpf = document.getElementById("cpf").value;
    let pessoa = new Pessoa(nome, altura, dataDeNascimento, cpf);
    let exiteNoSistema = verificar(cpf, ListaPessoa);
    if (nome !== null && altura !== null && dataDeNascimento !== null && cpf !== null){
        alert("Preencha os campos")
    }
        if (exiteNoSistema === null) {
            ListaPessoa.push(pessoa);
        }
        else {
            alert("Pessoa ja adicionada")
        }
}
function listar() {
    let saida = document.getElementById("saida");
    saida.innerHTML = "";
    for (let i = 0; i < ListaPessoa.length; i++) {
        let pessoa = ListaPessoa[i];
        saida.innerHTML += pessoa.nome + "---" + pessoa.altura + "---" + pessoa.dataDeNascimento + "---" + pessoa.cpf + "<br>";
    }
}
function verificar(cpf, ListaPessoa) {
    for (let i = 0; i < ListaPessoa.length; i++) {
        const pessoa = ListaPessoa[i];
        if (pessoa.cpf === cpf) {
            return pessoa
        }
    }
    return null;
}
function verificarNome(nome, ListaPessoa) {
    for (let i = 0; i < ListaPessoa.length; i++) {
        const pessoa = ListaPessoa[i];
        if (pessoa.nome === nome) {
            return pessoa
        }
    }
    return null;
}
function procurar() {
    const cpf = document.getElementById("cpf").value;
    let P = verificar(cpf, ListaPessoa);
    if (P !== null) {
        document.getElementById("nome").value = P.nome
        document.getElementById("altura").value = P.altura
        document.getElementById("dataDeNascimento").value = P.dataDeNascimento
        document.getElementById("cpf").value = P.cpf
    }
    else {
        alert("Pessoa não listada")
    }
}
function procurarPorNome() {
    const nome = document.getElementById("nome").value;
    let P = verificarNome(nome, ListaPessoa);
    if (P !== null) {
        document.getElementById("nome").value = P.nome
        document.getElementById("altura").value = P.altura
        document.getElementById("dataDeNascimento").value = P.dataDeNascimento
        document.getElementById("cpf").value = P.cpf
    }
    else {
        alert("Pessoa não listada")
    }
}
window.onload = listar()