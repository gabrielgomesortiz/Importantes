class Feramenta {
    constructor(id, nome, precoUnitario, peso, quantiadade, fabricante) {
        this.id = id;
        this.nome = nome;
        this.precoUnitario = precoUnitario;
        this.peso = peso;
        this.quantiadade = quantiadade;
        this.fabricante = fabricante;
    }
}
