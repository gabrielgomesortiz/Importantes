
let listaDeFeramentas = [
    new Feramenta(19, 'maetelo', 2.80, 90.3, 20, 'morgan friman'),
    new Feramenta(18, 'maetelo', 2.80, 90.3, 20, 'morgan friman'),
    new Feramenta(17, 'maetelo', 2.80, 90.3, 20, 'morgan friman'),
    new Feramenta(16, 'maetelo', 2.80, 90.3, 20, 'morgan friman')
]
function botaoInserir() {
    const idFerramenta = parseInt(document.getElementById("identificador").value);
    const nomeFerramenta = document.getElementById("nome").value;
    const preco = parseFloat(document.getElementById("precounitatario").value);
    const pesoDaferramenta = parseFloat(document.getElementById("peso").value);
    const quantiadade = parseInt(document.getElementById("quantiadade").value);
    const fabricante = document.getElementById("fabricante").value;
    let feramenta = new Feramenta(idFerramenta, nomeFerramenta, preco, pesoDaferramenta, quantiadade, fabricante)

    const f2 = buscarPorId(feramenta.id, listaDeFeramentas)
    if (f2 == null) {
        listaDeFeramentas.push(feramenta)
    }
    else {
        alert("já cadastrado com esse id")
    }

    console.log(listaDeFeramentas)
}
function buscarPorId(idFerramenta, listaDeFeramentas) {
    for (let i = 0; i < listaDeFeramentas.length; i++) {
        const f = listaDeFeramentas[i];
        if (f.id === idFerramenta) {
            return f;
        }
    }
    return null;
}
function listar() {
    let saida = document.getElementById("saida");
    saida.innerHTML = ''
    for (let i = 0; i < listaDeFeramentas.length; i++) {
        let f = listaDeFeramentas[i];
        saida.innerHTML += f.id + '-' + f.nome + '-' + f.precoUnitario + '-' + f.peso + '-' + f.quantiadade + '-' + f.fabricante + "<br>";
        limparCampos()
    }
}
function limparCampos() {
    document.getElementById("identificador").value = parseInt(100 * Math.random(Number))
    document.getElementById("nome").value = ''
    document.getElementById("precounitatario").value = parseInt(100 * Math.random(Number))
    document.getElementById("peso").value = parseInt(100 * Math.random(Number))
    document.getElementById("quantiadade").value = parseInt(100 * Math.random(Number))
    document.getElementById("fabricante").value = ''
}
function busquePeloId() {
    const idFerramenta = parseInt(document.getElementById("identificador").value);
    const f = buscarPorId(idFerramenta, listaDeFeramentas);
    if (f !== null) {
        document.getElementById("identificador").value = f.id;
        document.getElementById("nome").value = f.nome;
        document.getElementById("peso").value = f.peso;
        document.getElementById("precounitatario").value = f.precoUnitario;
        document.getElementById("quantiadade").value = f.quantiadade;
        document.getElementById("fabricante").value = f.fabricante;
    }
    else {
        alert('não existe na lista');
    }
}
window.onload=listar