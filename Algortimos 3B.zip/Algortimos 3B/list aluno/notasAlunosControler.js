let listaDeAlunos = [
    new Aluno("a2667223", "Lucas Almeida", 8.7, 9.6, 2.4, 9.0),
    new Aluno("a101001", "Mariana Costa", 8.7, 9.6, 2.4, 9.0),
    new Aluno("a101002", "João Pereira", 8.7, 9.6, 2.4, 9.0),
    new Aluno("a101003", "Ana Beatriz", 8.7, 9.6, 2.4, 9.0),
    new Aluno("a101004", "Bruno Cardoso", 7.8, 8.9, 9.0, 7.4),
    new Aluno("a101005", "Carla Mendes", 9.2, 8.1, 7.7, 8.5),
    new Aluno("a101006", "Felipe Souza", 6.5, 7.8, 8.9, 8.0),
    new Aluno("a101007", "Gabriela Oliveira", 8.9, 9.4, 7.5, 9.2),
    new Aluno("a101008", "Rafael Martins", 8.2, 7.9, 8.5, 8.6),
    new Aluno("a101009", "Bianca Ferreira", 7.5, 8.6, 9.0, 7.8),
    new Aluno("a101010", "Matheus Lima", 9.0, 8.8, 7.6, 9.1),
    new Aluno("a101012", "Gabriele Cardoso", 8.4, 9.1, 7.9, 8.3),
    new Aluno("a101011", "Adeilson Ortiz", 10.0, 10.0, 9.9, 10.0),
    new Aluno("a101011", "rosangela Gomes dos Santos", 8.4, 9.1, 7.9, 8.3),
    new Aluno("a101011", "Isabely Alcantara", 8.4, 9.1, 7.9, 8.3),
    new Aluno("a101011", "Victor Galadriel", 8.4, 9.1, 7.9, 8.3),
    new Aluno("a101011", "Zumeia Halmans", 10.0, 10.0, 9.9, 10.0),
    new Aluno("a101013", "Thiago Nunes", 7.5, 6.8, 8.2, 7.7),
    new Aluno("a101014", "Larissa Monteiro", 9.4, 8.9, 9.0, 9.5),
    new Aluno("a101015", "Caio Mendes", 5.5, 6.1, 7.0, 6.4),
    new Aluno("a101016", "Sofia Pereira", 8.8, 9.3, 7.9, 8.7),
    new Aluno("a101017", "Eduardo Ribeiro", 7.3, 7.2, 6.9, 7.1),
    new Aluno("a101018", "Beatriz Lima", 9.2, 9.0, 8.8, 9.3),
    new Aluno("a101019", "André Costa", 6.2, 7.0, 6.5, 6.8),
    new Aluno("a101020", "Giovana Almeida", 7.6, 8.0, 7.4, 7.8),
    new Aluno("a101021", "Luiz Santos", 8.9, 9.5, 8.7, 9.0),
    new Aluno("a101022", "Juliana Oliveira", 5.8, 6.0, 5.9, 6.1),
    new Aluno("a101023", "Fernando Batista", 9.0, 8.7, 9.1, 8.9),
    new Aluno("a101024", "Lívia Martins", 6.9, 7.1, 6.8, 7.0),
    new Aluno("a101025", "Henrique Souza", 9.6, 9.7, 9.8, 9.9),
    new Aluno("a101026", "Alice Rodrigues", 7.5, 7.6, 7.8, 7.7),
    new Aluno("a101027", "Pedro Silva", 5.9, 6.2, 6.0, 6.1),
    new Aluno("a101028", "Júlia Teixeira", 8.1, 7.9, 8.2, 8.0)
];

let media = [];

function inserirAluno() {
    const ra = document.getElementById("ra").value;
    const nome = document.getElementById("nome").value;
    const pBim = parseFloat(document.getElementById("pBim").value);
    const sBim = parseFloat(document.getElementById("sBim").value);
    const tBim = parseFloat(document.getElementById("tBim").value);
    const qBim = parseFloat(document.getElementById("qBim").value);

    let aluno = new Aluno(ra, nome, pBim, sBim, tBim, qBim);

    let alunoExistentePorRa = VerificarAlunoNaLIsta(aluno.ra, listaDeAlunos);
    let alunoExistentePorNome = VerificarAlunoNaLIstaNome(aluno.nome, listaDeAlunos);
    if(ra != null && nome != null && pBim != null && sBim != null && tBim != null && qBim != null){
        alert("Preencha os campos");
    }
    else if (alunoExistentePorRa === null && alunoExistentePorNome === null) {
        listaDeAlunos.push(aluno);
    } else {
        alert("Aluno já está listado");
    }
    
}

function listarAlunos() {
    let saida = document.getElementById("saida");
    saida.innerHTML = '';
    for (let i = 0; i < listaDeAlunos.length; i++) {
        let A = listaDeAlunos[i];
        saida.innerHTML += A.ra + "--" + A.nome + "--" + A.pBim + "--" + A.sBim + '--' + A.tBim + '--' + A.qBim + "<br>";
    }
    limparCamposErandomizar()
}

function VerificarAlunoNaLIsta(ra,listaDeAlunos){
    for(let i=0;i<listaDeAlunos.length;i++){
        const comparar=listaDeAlunos[i];
        if(ra=comparar.ra){
            return comparar;
        }
    }
    return null
}

function VerificarAlunoNaLIstaNome(nome, listaDeAlunos) {
    for (let i = 0; i < listaDeAlunos.length; i++) {
        const comparar = listaDeAlunos[i];
        if (comparar.nome === nome) {
            return comparar; // Se o nome for igual, retorna o aluno
        }
    }
    return null; // Se não encontrar, retorna null
}

function ProcurarRa(){
    let ra=document.getElementById("ra").value;
    let a= VerificarAlunoNaLIsta(ra,listaDeAlunos);
    if(a!==null){
        document.getElementById("ra").value = a.ra;
        document.getElementById("nome").value = a.nome;
        document.getElementById("pBim").value = a.pBim;
        document.getElementById("sBim").value = a.sBim;
        document.getElementById("tBim").value = a.tBim;
        document.getElementById("qBim").value = a.qBim;
    }
    else{
        alert("aluno inexistente")
    }
}
function ProcurarNome() {
    const nome = document.getElementById("nome").value;
    const a = VerificarAlunoNaLIstaNome(nome, listaDeAlunos);
    if (a !== null) {
        document.getElementById("ra").value = a.ra;
        document.getElementById("nome").value = a.nome;
        document.getElementById("pBim").value = a.pBim;
        document.getElementById("sBim").value = a.sBim;
        document.getElementById("tBim").value = a.tBim;
        document.getElementById("qBim").value = a.qBim;
    } else {
        alert("Aluno não listado");
    }
}
function limparCamposErandomizar() {
    document.getElementById("ra").value = ''
    document.getElementById("nome").value = ''
    document.getElementById("pBim").value = ''
    document.getElementById("sBim").value = '';
    document.getElementById("tBim").value = '';
    document.getElementById("qBim").value = '';
}
function listarAlunosComMesmasLetras() {
    let listaDeAlunosLetras = '';
    const letras = document.getElementById("letras").value.toLowerCase();
    for (let i = 0; i < listaDeAlunos.length; i++) {
        let aluno = listaDeAlunos[i];
        let primeiraLetra = aluno.nome[0].toLowerCase();
        if (letras === primeiraLetra) {
            listaDeAlunosLetras += aluno.ra + " -- " + aluno.nome + "<br>";
        }
    }
    document.getElementById("saidaLetras").innerHTML = listaDeAlunosLetras;
}
function mediaAlunos() {
    let saida = document.getElementById("mediaAlunos");
    let somarNotas = 0;
    for (let i = 0; i < listaDeAlunos.length; i++) {
        let f = listaDeAlunos[i];
        somarNotas = f.qBim + f.sBim + f.tBim + f.qBim;
        saida.innerHTML += "Aluno(a):" + f.nome + "sua media foi igual a " + (somarNotas / 4).toFixed(2) + '<br>'
    }
}

function MaiorMediaSala() {
    let mediaDaSala = 0
    let alunosMaiorMedia = [];
    for (let i = 0; i < listaDeAlunos.length; i++) {
        let aluno = listaDeAlunos[i];
        let media = (aluno.pBim + aluno.sBim + aluno.tBim + aluno.qBim) / 4;
        let comparar = parseInt(media);
        if (mediaDaSala <= comparar) {
            mediaDaSala = comparar
        }
    }
    for (let i = 0; i < listaDeAlunos.length; i++) {
        let aluno2 = listaDeAlunos[i];
        let media1 = (aluno2.pBim + aluno2.sBim + aluno2.tBim + aluno2.qBim) / 4;
        if (media1 >= mediaDaSala) {
            alunosMaiorMedia.push(aluno2.nome + " esse aluno obteve media igual: " + media1 + '<br>')
        }
    }

    document.getElementById("MaiorMedia").innerHTML = alunosMaiorMedia;
}
function Situacao() {
    let saida = document.getElementById("SituacaoAluno");
    for (let i = 0; i < listaDeAlunos.length; i++) {
        let ReprovOuAprov = ''
        let A = listaDeAlunos[i];
        let media = (A.pBim + A.sBim + A.tBim + A.qBim) / 4;
        if (media < 6) {
            ReprovOuAprov = "reprovado";
        }
        else {
            ReprovOuAprov = "Aprovado";
        }
        saida.innerHTML += A.ra + " -- " + A.nome + " -- " + A.pBim + " -- " + A.sBim + ' -- ' + A.tBim + ' -- ' + A.qBim + media.toFixed(2) + " -- " + ReprovOuAprov + "<br>";
    }
}

window.onload = listarAlunos;