class Aluno{
    constructor(ra,nome,pBim,sBim,tBim,qBim){
        this.ra=ra;
        this.nome=nome;
        this.pBim=pBim;
        this.sBim=sBim;
        this.tBim=tBim;
        this.qBim= qBim;
    }
}