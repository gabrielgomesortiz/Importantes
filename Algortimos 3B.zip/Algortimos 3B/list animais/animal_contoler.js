
let listaDeAnimais=[];

function inserirNaLista(){
    const id= document.getElementById("identificador").value;
    const nome= document.getElementById("nome").value;
    const especie= document.getElementById("especie").value;
    const peso= parseFloat(document.getElementById("peso").value);
    const dataDeNascimento= document.getElementById("dataDeNascimento").value;
    let linha=new animal(id,nome,especie,peso,dataDeNascimento)
    listaDeAnimais.push(linha)
    alert("inserido com sucesso")
    }

function listar(){
    let i=0; 
    let saida=  document.getElementById("saida");
    saida.innerHTML=''
    while(i< listaDeAnimais.length){
        let animal= listaDeAnimais[i];
        saida.innerHTML+= animal.id+' - '+animal.nome+' - '+animal.especie+' - '+animal.peso+' e a data: '+animal.dataDeNascimento+'-'+"<br>"
        i++
    }
}
