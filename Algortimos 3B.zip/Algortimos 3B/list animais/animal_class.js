
class animal{
    constructor(id,nome,especie,peso,dataDeNascimento){
        this.id=id;
        this.nome=nome;
        this.especie=especie;
        this.peso= peso;
        this.dataDeNascimento= dataDeNascimento;
    }
}