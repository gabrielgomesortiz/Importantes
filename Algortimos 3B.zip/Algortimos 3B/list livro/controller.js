let listaDeLivros = [];
let funcaoLivros = livrosJaListados(listaDeLivros)
function inserir() {
    const isbn = parseFloat(document.getElementById("isbn").value);
    const titulo = document.getElementById("titulo").value;
    const autor = document.getElementById("autor").value;
    const anoDePublicacao = document.getElementById("anoDepublicacao").value;
    const preco = parseFloat(document.getElementById("preco").value);

    let livro = new Livro(isbn, titulo, autor, anoDePublicacao, preco);
    let verificacao = verificar(isbn, listaDeLivros);
    if (verificacao === null) {
        listaDeLivros.push(livro);
    }
    else {
        alert("O livro ja existe")
    }
}

function livrosJaListados() {
    let livro = new Livro(123, "gabr", "Gabriel", 2024, 90.23)
    listaDeLivros.push(livro);

    livro = new Livro(1233, "gabrre", "Gabriel Ortiz", 2024, 100.23)
    listaDeLivros.push(livro);

    livro = new Livro(1253, "foda", "Gabriel gomes", 1998, 80.23)
    listaDeLivros.push(livro);

    livro = new Livro(9, "Ortiz Programer", "Gabriel Ortiz", 1998, 70.23)
    listaDeLivros.push(livro);

    livro = new Livro(12390, "Genio da programação", "Gabriel Gomes Ortiz", 2008, 190.23)
    listaDeLivros.push(livro);
}
function verificar(isbn, listaDeLivros) {
    for (let i = 0; i < listaDeLivros.length; i++) {
        let livro = listaDeLivros[i];
        if (livro.isbn === isbn) {
            return livro
        }
    }
    return null;
}

function procurar() {
    const isbn = parseFloat(document.getElementById("isbn").value);
    let l = verificar(isbn, listaDeLivros);
    if (l !== null) {
        document.getElementById("isbn").value = l.isbn;
        document.getElementById("titulo").value = l.titulo;
        document.getElementById("autor").value = l.autor;
        document.getElementById("anoDepublicacao").value = l.anoDePublicacao;
        document.getElementById("preco").value = l.preco;
    }
    else {
        alert('livro não lsitado');
    }
}

function mesmoAnoDePublicacao() {
    const anoDePublicacao = parseInt(document.getElementById("anoDepublicacao").value);
    let saida = document.getElementById("saida3");
    saida.innerHTML = "Livros do mesmo ano de publicaçao" + '<br>';
    for (let i = 0; i < listaDeLivros.length; i++) {
        let livro = listaDeLivros[i];
        if (anoDePublicacao == livro.anoDePublicacao) {
            saida.innerHTML += 'Titulo: <strong>' + livro.titulo + '</strong>' + '<br>'
        }
    }
}

function mostrarTitulos() {
    let saida = document.getElementById("saida2");
    saida.innerHTML = "Acervo disponíveis no momento" + '<br>';
    for (let i = 0; i < listaDeLivros.length; i++) {
        let livro = listaDeLivros[i];
        saida.innerHTML += 'Titulo: <strong>' + livro.titulo + '</strong>' + '<br>'
    }
}
function listar() {
    let saida = document.getElementById("saida");
    saida.innerHTML = "";
    for (let i = 0; i < listaDeLivros.length; i++) {
        let livro = listaDeLivros[i];
        saida.innerHTML += 'Isbn: ' + livro.isbn + "--- Titúlo: " + livro.titulo + '--- Autor: ' + livro.autor + "--- Ano de publicação: " + livro.anoDePublicacao + "--- Preço: R$ " + livro.preco + '<br>'
    }
}
window.onload = listar();