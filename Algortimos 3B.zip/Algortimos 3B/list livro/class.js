class Livro{
    constructor(isbn,titulo,autor,anoDePublicacao,preco){
        this.isbn=isbn;
        this.titulo=titulo;
        this.autor=autor;
        this.anoDePublicacao=anoDePublicacao;
        this.preco=preco;
    }
}