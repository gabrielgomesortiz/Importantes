const express = require('express');
const { OpenAI } = require('openai');
require('dotenv').config(); // Carregar variáveis do .env

const app = express();
app.use(express.json());

const openai = new OpenAI({
  apiKey: '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', // Usa a chave da API do .env
});

// Rota para gerar imagens
app.post('/gerar-imagem', async (req, res) => {
  try {
    const { descricao } = req.body;

    if (!descricao) {
      return res.status(400).json({ success: false, message: 'A descrição é obrigatória.' });
    }

    const response = await openai.images.generate({
      prompt: descricao,
      n: 1,
      size: "1024x1024",
    });

    const imagemUrl = response.data[0].url;
    res.json({ success: true, imagemUrl });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: 'Erro ao gerar a imagem.' });
  }
});

// Inicializar o servidor
const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
