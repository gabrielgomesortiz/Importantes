let listaJoias = []; 
let oQueEstaFazendo = ''; 
let joias = null; 
bloquearAtributos(true);

function fazerDownload () {
    nomeParaSalvar = "arquivo.csv";
    let textoCSV = "";
    for (let i =0; i <
    listaJoias.length; i++) {
    const linha = listaJoias[i];
    textoCSV += linha.id + ";" +
    linha.inputNome + ";" +
    linha.inputMetal + ";" + 
    linha.inputDataFabricacao + ";" + 
    linha.inputTipo + "/n";
    }
    salvarEmArquivo(nomeParaSalvar, textoCSV);
}    


function salvarEmArquivo (nomeAra, conteudo)
{
const blob = new Blob([conteudo],
{ type: "text/plain" });
const link =
document.createElement("a");
link.href = URL.createObjectURL(blob);
link.download = nomeAra;
link.click();
URL.revokeObjectURL(link.href);
}

function fazerUploand(){
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".csv";
    input.onchange = function (event){
        console.log(arquivo.name);
        if (arquivo){
            processarArquivo(arquivo);
        }
    };
    input.click();
}

function processarArquivo(arquivo){
    const leitor = new FileReader();
    leitor.onload = function(e){
        const conteudo = e.target.result;
        const linhas = conteudo.split("/n");
        listaDeJoias = [];
        for (let i = 0; i < linhas.length; i++){
            const linha = linhas[i].trim();
            if (linha){//verifica se a linha nao esta vazia
                const dados = linha.slipt(";");
                if (dados.length ===5){
                    listaDeJoias.push({
                        id: dados[0],
                        inputNome: dados[1],
                        inputMetal: dados[2],
                        inputDataFabricacao: dados[3],
                        inputTipo: dados[4]
                    });
                }

            }
        }
        listar();
        alert(listaDeJoias)
    };
    leitor.readAsText(arquivo);
} 
function procurePorChavePrimaria(chave) {
    for (let i = 0; i < listaJoias.length; i++) {
        const joia = listaJoias[i];
        if (joia.id === chave) {
            joia.posicaoNaLista = i;
            return listaJoias[i];
        }
    }
    return null;
}

function procure() {
    const id = parseInt(document.getElementById("inputId").value);
    if  (id) {
     joias = procurePorChavePrimaria(id); if (joias){
        mostrarDadosJoias(joias);
        visibilidadeDosBotoes("inline", "none", "inline", "inline", "none");
        mostrarAviso("Achou na lista, pode alterar ou excuir");
     }else{
        limparAtributos();
        visibilidadeDosBotoes("none", "inline", "none", "none", "none");
        mostrarAviso("Não achou na lista, pode inserir");
     }
    }else{
        document.getElementById("inputId").focus();
        return;
     }
    }
    
function inserir() {
    bloquearAtributos(false);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');
    oQueEstaFazendo = 'inserindo';
    mostrarAviso("INSERINDO - Digite os atributos e clique o botão salvar");
    document.getElementById("inputId").focus();
}
function alterar() {
    bloquearAtributos(false);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');
    oQueEstaFazendo = 'alterando';
    mostrarAviso("ALTERANDO - Digite os atributos e clique em salvar.");
}

function excluir() {
    bloquearAtributos(false)
    visibilidadeDosBotoes("none", "none", "none", "none", "inline");
    oQueEstaFazendo = 'excluindo';
    mostrarAviso("EXCLUINDO - Clique em salvar para confirmar.");
}

    async function salvar() {
       
            let id;
            if (joias == null) {
                id = document.getElementById("inputId").value;
            } else {
                id = joias.id;
            }
            const inputNome = document.getElementById("inputNome").value;
            const inputMetal = document.getElementById("inputMetal").value;
            const inputDataFabricacao = document.getElementById("inputDataFabricacao").value;
            const inputTipo = document.getElementById("inputTipo").value;
        
            if (id != null && id > 0 && inputNome && inputMetal && inputDataFabricacao && inputTipo) {
                if (oQueEstaFazendo === "inserindo" && procurePorChavePrimaria(id)) {
                    mostrarAviso("Erro, já existe um item com este ID");
                    return;
                }
        
                switch (oQueEstaFazendo) {
                    case "inserindo":
                        joias = new Joias(id, inputNome, inputMetal, inputDataFabricacao, inputTipo);
                        listaJoias.push(joias);
                        mostrarAviso("Inserido na lista");
        
                        // Adicionando a geração da imagem
                        const descricao = Uma joia feita de ${inputMetal} com o nome ${inputNome}, tipo ${inputTipo}, fabricada em ${inputDataFabricacao}.;
                        ;
                        try {
                            const imagemResponse = await fetch('http://localhost:4000/gerar-imagem', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                                body: JSON.stringify({ descricao })
                            });
        
                            const imagemData = await imagemResponse.json();
        
                            if (imagemData.sucesso) {
                                joias.imagemUrl = imagemData.imagemUrl; // Adicionando a URL da imagem à joia
                                mostrarAviso(Imagem gerada com sucesso!);
                            } else {
                                mostrarAviso(Erro ao gerar a imagem.);
                            }
                        } catch (error) {
                            console.error('Erro ao gerar imagem:', error);
                            mostrarAviso('Erro ao gerar imagem.');
                        }
                        break;
                    case "alterando":
                        joiasAlterado = new Joias(id, inputNome, inputMetal, inputDataFabricacao, inputTipo);
                        listaJoias[joias.posicaoNaLista] = joiasAlterado;
                        mostrarAviso("Alterado");
        
                        // Opcional: Gerar imagem também na alteração, se necessário
                        break;
                    case "excluindo":
                        let novaLista = [];
                        for (let i = 0; i < listaJoias.length; i++) {
                            if (joias.posicaoNaLista != i) {
                                novaLista.push(listaJoias[i]);
                            }
                        }
                        listaJoias = novaLista;
                        mostrarAviso("EXCLUÍDO");
                        break;
                    default:
                        mostrarAviso("Erro aleatório");
                }
                visibilidadeDosBotoes("inline", "none", "none", "none", "none");
                limparAtributos();
                listar();
                document.getElementById("inputId").focus();
            } else {
                alert("Erro nos dados digitados");
                return;
            }
        }
    
        
        function procurePorChavePrimaria(id) {
            return listaJoias.find(joia => joia.id === id);
        }
        

        
        function visibilidadeDosBotoes(btProcure, btInserir, btAlterar, btExcluir, btSalvar) {
            // Exemplo de como controlar a visibilidade dos botões
        }
        
        function limparAtributos() {
            // Limpar os campos de entrada
        }
        
    





function listar() {
    document.getElementById("outputSaida").innerHTML = preparaListagem(listaJoias);
}


function cancelarOperacao() {
    limparAtributos();
    bloquearAtributos(true);
    visibilidadeDosBotoes("inline", "none", "none", "none", "none");
    mostrarAviso
        ("Cancelou a operaÃ§Ã£o de ediÃ§Ã£o");
}



function mostrarAviso(mensagem) {
    document.getElementById("divAviso").innerHTML = mensagem;
}



function mostrarDadosJoias(joias) {
    document.getElementById("inputNome").value = joias.nome;
    document.getElementById("inputMetal").value = joias.metal;
    document.getElementById("inputDataFabricacao").value = joias.dataFabricacao;
    document.getElementById("inputTipo").value = joias.tipo;
    bloquearAtributos(true);
}


function limparAtributos() {
    document.getElementById("inputNome").value = "";
    document.getElementById("inputMetal").value = "";
    document.getElementById("inputDataFabricacao").value = "";
    document.getElementById("inputTipo").value = "";

    bloquearAtributos(true);
}


function bloquearAtributos(soLeitura) {
    document.getElementById("inputId").readOnly = !soLeitura;
    document.getElementById("inputNome").readOnly = soLeitura;
    document.getElementById("inputMetal").readOnly = soLeitura;
    document.getElementById("inputDataFabricacao").readOnly = soLeitura;
    document.getElementById("inputTipo").readOnly = soLeitura;
}

function visibilidadeDosBotoes(btProcure, btInserir, btAlterar, btExcluir, btSalvar) {
    document.getElementById("btProcure").style.display = btProcure;
    document.getElementById("btInserir").style.display = btInserir;
    document.getElementById("btAlterar").style.display = btAlterar;
    document.getElementById("btExcluir").style.display = btExcluir;
    document.getElementById("btSalvar").style.display = btSalvar;
    document.getElementById("btCancelar").style.display = btSalvar;
    document.getElementById("inputId").focus();
}